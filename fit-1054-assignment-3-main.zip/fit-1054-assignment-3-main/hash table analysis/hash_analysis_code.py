from hash_table import LinearProbeTable

hash_bases = [1, 9929, 250726, 24]
table_sizes = [20021, 402221, 1000081]


# data from aust_cities
with open('aust_cities.txt', 'r') as fileref:
    aust_cities = [line.strip() for line in fileref]

# data from indian_cities
with open('indian_cities.txt', 'r') as fileref:
    india_cities = [line.strip() for line in fileref]

# data from us_cities
with open('us_cities.txt', 'r') as fileref:
    us_cities = [line.strip() for line in fileref]

data = [aust_cities, india_cities, us_cities]

# desting different table sizes
cities = ["Australia", "India", "US"]

print("- - - - - - - - - - - - - ")
print("  testing table size")
print("- - - - - - - - - - - - - ")
for i in range(len(data)):
    for size in table_sizes:
        h = LinearProbeTable(len(aust_cities), size)
        for city in data[i]:
            h[city] = None
        print("statistics of", cities[i], "with table size", size)
        print("hash table is", round(len(h)/h.tablesize * 100, 2), "% full")
        print(h.statistics())
    print()
print()



# # conflicts count, probe total, probe max, rehash
# print(h.statistics())

print("- - - - - - - - - - - - - ")
print("  testing hash base")
print("- - - - - - - - - - - - - ")
for i in range(len(data)):
    for base in hash_bases:
        h = LinearProbeTable(len(aust_cities), table_sizes[0], base)
        for city in data[i]:
            h[city] = None
        print("statistics of", cities[i], "with hash base", base)
        print("hash table is", round(len(h)/h.tablesize * 100, 2), "% full")
        print(h.statistics())
        

    print()
print()
print("- - - - - - - - - - - - - ")
print("  testing anagrams")
print("- - - - - - - - - - - - - ")
with open('anagrams.txt', 'r') as fileref:
    anagrams = [line.strip() for line in fileref]

for base in hash_bases:
    h = LinearProbeTable(len(anagrams), hash_base=base)
    for word in anagrams:
        h[word] = None
    print("statistics of anagrams with hash base", base)
    print("hash table is", round(len(h)/h.tablesize * 100, 2), "% full")
    print(h.statistics())

print()
